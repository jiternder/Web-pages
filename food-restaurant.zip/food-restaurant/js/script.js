const btnNavEl = document.querySelector(".btn-mobile-nav");
const headerEl = document.querySelector(".header");

btnNavEl.addEventListener("click", function () {
  headerEl.classList.toggle("nav-open");
});

$(".header .main-nav ul li a").click(function (e) {
  e.stopPropagation();
  $(".header").removeClass("nav-open");
});
