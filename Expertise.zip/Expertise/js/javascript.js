/****Service-img****/
$('.service-carousal').owlCarousel({
    loop:true,
    margin:2,
    nav:false,
    dots:false,
    autoplay:true,
    autoplaySpeed:1000,
    autoplayTimeout:2000,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:3
        }
    }
})
/*****Our-team*****/
$('.our-team-img').owlCarousel({
    loop:false,
    margin:2,
    nav:false,
    dots:false,
    autoplay:false,
    responsive:{
        0:{
            items:2
        },
        600:{
            items:4
        },
        1000:{
            items:8
        }
    }
})
/********Scroll animation**********/
// find the top of each section
var sectionA = $('.section-a').offset().top;

// number of pixels before the section to start animation
var scrollOffset = 50; 

// run this function when the window scrolls
$(window).scroll(function() {  
  
  // get the window height on scroll
  var scroll = $(window).scrollTop() + scrollOffset;  
  
  // if scroll hits the top of section-a
  if ( scroll > sectionA ) {
    $('.section-a .hero-title').addClass('animate-normal');
    $('.section-a .hero-subtitle').addClass('animate-delay');
  }
});


